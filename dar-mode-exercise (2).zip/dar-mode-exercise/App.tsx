import Home from './src/app/home';
import { Provider } from 'react-redux';
import { store } from './src/store';

export default function App() {
  return (
    <Provider store={store}>
      <Home />
    </Provider>
  )
}
