import { StatusBar } from "expo-status-bar";
import { StyleSheet, Text, View } from "react-native";
import { useSelector } from "react-redux";
import { RootState } from "../store";
import ThemeToggle from "../components/themeToggle";

export default function Home() {
  const theme = useSelector((state: RootState) => state.theme.theme);
  const isDark = theme === "dark";

  return (
    <View
      style={[styles.container, { backgroundColor: isDark ? "#333" : "#fff" }]}
    >
      <Text style={{ color: isDark ? "#FFF" : "#333" }}>
        Tema atual: {theme}
      </Text>
      <ThemeToggle />
      <StatusBar style="auto" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
});
