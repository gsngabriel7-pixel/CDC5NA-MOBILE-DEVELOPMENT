import { configureStore } from "@reduxjs/toolkit";
import chatReducer from "./chatSlice";

export const store = configureStore({
    reducer: {
        chat: chatReducer,
        // Aqui você pode adicionar outros reducers se tiver mais slices
    }
})

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;