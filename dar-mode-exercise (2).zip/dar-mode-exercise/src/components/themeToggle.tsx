import { Button } from "react-native";
import { useDispatch } from "react-redux";
import { toggleTheme } from "../store/themeSlice";
import { AppDispatch } from "../store";

export default function ThemeToggle() {
  const dispatch = useDispatch<AppDispatch>();

  return <Button title="Trocar tema" onPress={() => dispatch(toggleTheme())} />;
}
