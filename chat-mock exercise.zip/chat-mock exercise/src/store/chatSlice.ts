import { createSlice, PayloadAction } from "@reduxjs/toolkit";

type Message = {
    id : string;
    text: string;
    sender: "user" | "bot"
}

type chatState = {
    messages: Message[];
}

const initialState: chatState = {
    messages: []
}

const chatSlice = createSlice({
    name: "chat",
    initialState,
    reducers: {
        addMessage: (state, action: PayloadAction<string>) => {
            state.messages.push({
                id: Date.now().toString(),
                text: action.payload,
                sender: "user"
            })
        },

        receiveMessage: (state, action: PayloadAction<string>) => {
            state.messages.push({
                id: Date.now().toString(),
                text: action.payload,
                sender: "bot"
            })
        },

        cleanchat: (state) => {
            state.messages = [];
        }
    }
});

export const {addMessage, receiveMessage, cleanchat} = chatSlice.actions;
export default chatSlice.reducer;


